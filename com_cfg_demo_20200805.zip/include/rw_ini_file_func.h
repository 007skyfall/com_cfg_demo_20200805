#ifndef __RW_INI_FILE_FUNC_H__
#define __RW_INI_FILE_FUNC_H__


#include <stdio.h>
#include "iniparser.h"

#ifdef __cplusplus
extern "C"
{
#endif

dictionary* OpenINI(const char* lpFileName);
void CloseINI(dictionary* ini);
int SaveINI(dictionary * d, const char *lpFileName);

int GetPrivateProfileInt(const char*lpAppName, const char* lpKeyName, int nDefault, dictionary* ini);
double GetPrivateProfileDouble(const char*lpAppName, const char* lpKeyName, double nDefault, dictionary* ini);
long GetPrivateProfileLong(const char* lpAppName, const char* lpKeyName, long nDefault, dictionary* ini);
void GetPrivateProfileString(const char* lpAppName, const char* lpKeyName, char*lpRet, const char* lpDefault, dictionary* ini);

//��Ҫ����int SaveINI(dictionary * d, const char *lpFileName);���ܱ����ļ�,Ȼ����CloseINI()
int WritePrivateProfileInt(const char* lpAppName, const char* lpKeyName, int nVal, dictionary* ini);
int WritePrivateProfileLong(const char* lpAppName, const char* lpKeyName, long lnVal, dictionary* ini);
int WritePrivateProfileDouble(const char* lpAppName, const char* lpKeyName, double dVal, dictionary* ini);
int WritePrivateProfileString(const char* lpAppName, const char* lpKeyName, const char* lpVal, dictionary* ini);

#if 0
int GetPrivateProfileInt(const char*lpAppName,const char* lpKeyName,int nDefault,const char* lpFileName);
double GetPrivateProfileDouble(const char*lpAppName,const char* lpKeyName,double nDefault,const char* lpFileName);
long GetPrivateProfileLong(const char* lpAppName,const char* lpKeyName,long nDefault,const char* lpFileName);
void GetPrivateProfileString(const char* lpAppName,const char* lpKeyName,char*lpRetDefault,const char* lpDefault,const char* lpFileName);

int WritePrivateProfileInt(const char* lpAppName,const char* lpKeyName,int nVal,const char* lpFileName);
int WritePrivateProfileLong(const char* lpAppName,const char* lpKeyName,long lnVal,const char* lpFileName);
int WritePrivateProfileDouble(const char* lpAppName,const char* lpKeyName,double dVal,const char* lpFileName);
int WritePrivateProfileString(const char* lpAppName,const char* lpKeyName,const char* lpVal,const char* lpFileName);
int iniparser_save(dictionary * d, const char *lpFileName);
#endif


#ifdef __cplusplus
}
#endif

#endif
