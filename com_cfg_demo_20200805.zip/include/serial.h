#ifndef __SERIAL_H__
#define __SERIAL_H__


//open serial

int open_port(char *Dev);

//set port

int set_opt(int fd,int nSpeed, int nBits, char nEvent, int nStop);

//read port 
int read_port(int fd, char *buf,int len,int maxwaittime_ms_less1S);



#endif  //__SERIAL_H__

