#include "rw_ini_file_func.h"

#ifdef __cplusplus
extern "C"
{
#endif

dictionary* OpenINI(const char* lpFileName)
{
	dictionary* ini = iniparser_load(lpFileName);
	if (ini == NULL)
	{
		printf("open %s failed\n", lpFileName);
	}
	return ini;
}
void CloseINI(dictionary* ini)
{
	if (ini)
		iniparser_freedict(ini);
}

int GetPrivateProfileInt(const char*lpAppName, const char* lpKeyName, int nDefault, dictionary* ini)
{
	if (ini == NULL)
	{
		return nDefault;
	}
	char str[256];
	sprintf(str, "%s:%s", lpAppName, lpKeyName);
	int ret = iniparser_getint(ini, (const char*)str, nDefault);
	return ret;
}
double GetPrivateProfileDouble(const char*lpAppName, const char* lpKeyName, double dDefault, dictionary* ini)
{
	if (ini == NULL)
	{
		return dDefault;
	}
	
	char str[256];
	sprintf(str, "%s:%s", lpAppName, lpKeyName);
	double ret = iniparser_getdouble(ini, (const char*)str, dDefault);
	return ret;
}

long GetPrivateProfileLong(const char* lpAppName, const char* lpKeyName, long lnDefault, dictionary* ini)
{
	if (ini == NULL)
	{
		return lnDefault;
	}

	char str[256];
	sprintf(str, "%s:%s", lpAppName, lpKeyName);
	long ret = iniparser_getlongint(ini, (const char*)str, lnDefault);

	return ret;
}

void GetPrivateProfileString(const char* lpAppName, const char* lpKeyName, char*lpRet, const char* lpDefault, dictionary* ini)
{
	if (ini == NULL)
	{
		sprintf(lpRet, "%s", lpDefault);
		return;
	}

	char str[256];
	sprintf(str, "%s:%s", lpAppName, lpKeyName);
	const char* ret = iniparser_getstring(ini, (const char*)str, lpDefault);
	sprintf(lpRet, "%s", ret);

	return;
}

//��Ҫ����int SaveINI(dictionary * d, const char *lpFileName);���ܱ����ļ�
int WritePrivateProfileInt(const char* lpAppName, const char* lpKeyName, int nVal, dictionary* ini)
{
	if (ini == NULL)
		return -1;

	char str[256];
	char lpVal[128];

	sprintf(str, "%s:%s", lpAppName, lpKeyName);
	sprintf(lpVal, "%d", nVal);
	int ret = iniparser_set(ini, (const char*)str, (const char*)lpVal);

	return ret;
}

int WritePrivateProfileLong(const char* lpAppName, const char* lpKeyName, long lnVal, dictionary* ini)
{
	if (ini == NULL)
		return -1;

	char str[256];
	char lpVal[128];
	sprintf(str, "%s:%s", lpAppName, lpKeyName);
	sprintf(lpVal, "%ld", lnVal);

	int ret = iniparser_set(ini, (const char*)str, (const char*)lpVal);

	return ret;
}

int WritePrivateProfileDouble(const char* lpAppName, const char* lpKeyName, double dVal, dictionary* ini)
{
	if (ini == NULL)
		return -1;

	char str[256];
	char lpVal[128];
	sprintf(str, "%s:%s", lpAppName, lpKeyName);
	sprintf(lpVal, "%lf", dVal);
	int ret = iniparser_set(ini, (const char*)str, (const char*)lpVal);
	return ret;
}

int WritePrivateProfileString(const char* lpAppName, const char* lpKeyName, const char* lpVal, dictionary* ini)
{
	if (ini == NULL)
		return -1;

	char str[256];
	sprintf(str, "%s:%s", lpAppName, lpKeyName);

	int ret = iniparser_set(ini, (const char*)str, lpVal);
	return ret;
}

int SaveINI(dictionary * d, const char *lpFileName)
{
	int ret = 0;
	FILE *fp = NULL;

	if (lpFileName == NULL || d == NULL) 
	{
		printf("saveConfig error:%d from (filepath == NULL || head == NULL)\n", ret);
		return -1;
	}

	fp = fopen(lpFileName, "w");
	if (fp == NULL) 
	{
		printf("saveConfig:open file error:%d from %s\n", ret, lpFileName);
		return -2;
	}

	iniparser_dump_ini(d, fp);

	fclose(fp);

	return 0;
}


#if 0
int GetPrivateProfileInt(const char*lpAppName,const char* lpKeyName,int nDefault,const char* lpFileName)
{
	 dictionary* ini;
	 char str[64];
	 ini = iniparser_load(lpFileName);
	 if(ini==NULL)
	 {
	 	printf("open %s failed\n",lpFileName);
		return -1;
	 }
	 sprintf(str,"%s:%s",lpAppName,lpKeyName);
	 int ret=iniparser_getint(ini,(const char*)str,nDefault);
	 iniparser_freedict(ini);
	 return ret;
}
double GetPrivateProfileDouble(const char*lpAppName,const char* lpKeyName,double dDefault,const char* lpFileName)
{
	dictionary* ini;
	char str[64];
	ini = iniparser_load(lpFileName);
	if(ini==NULL)
	{
		printf("open %s failed\n",lpFileName);
		return -1;
	}
	sprintf(str,"%s:%s",lpAppName,lpKeyName);
	double ret=iniparser_getdouble(ini,(const char*)str,dDefault);
	iniparser_freedict(ini);
	return ret;
}

long GetPrivateProfileLong(const char* lpAppName,const char* lpKeyName,long lnDefault,const char* lpFileName)
{
	dictionary* ini;
	char str[64];
	ini = iniparser_load(lpFileName);
	if(ini==NULL)
	{
		printf("open %s failed\n",lpFileName);
		return -1;
	}
	sprintf(str,"%s:%s",lpAppName,lpKeyName);
	long ret=iniparser_getlongint(ini,(const char*)str,lnDefault);
	iniparser_freedict(ini);
	return ret;
}

void GetPrivateProfileString(const char* lpAppName,const char* lpKeyName,char*lpRetDefault,const char* lpDefault,const char* lpFileName)
{
	dictionary* ini;
	char str[64];
	ini = iniparser_load(lpFileName);
	if(ini==NULL)
	{
		printf("open %s failed\n",lpFileName);
		return;
	}
	sprintf(str,"%s:%s",lpAppName,lpKeyName);
	const char* ret=iniparser_getstring(ini,(const char*)str,lpDefault);
	sprintf(lpRetDefault,"%s",ret);
	iniparser_freedict(ini);
	return;
}

int WritePrivateProfileInt(const char* lpAppName,const char* lpKeyName,int nVal,const char* lpFileName)
{
	dictionary* ini;
	char str[64];
	char lpVal[128];
	ini = iniparser_load(lpFileName);
	if(ini==NULL)
	{
		printf("open %s failed\n",lpFileName);
		return -1;
	}
	sprintf(str,"%s:%s",lpAppName,lpKeyName);
	sprintf(lpVal,"%d",nVal);
	int ret=iniparser_set(ini,(const char*)str,(const char*)lpVal);
	iniparser_save(ini,lpFileName);
	iniparser_freedict(ini);
	return ret;
}

int WritePrivateProfileLong(const char* lpAppName,const char* lpKeyName,long lnVal,const char* lpFileName)
{

	dictionary* ini;
	char str[64];
	char lpVal[128];
	ini = iniparser_load(lpFileName);
	if(ini==NULL)
	{
		printf("open %s failed\n",lpFileName);
		return -1;
	}
	sprintf(str,"%s:%s",lpAppName,lpKeyName);
	sprintf(lpVal,"%ld",lnVal);
	int ret=iniparser_set(ini,(const char*)str,(const char*)lpVal);
	iniparser_save(ini,lpFileName);
	iniparser_freedict(ini);
	return ret;
}

int WritePrivateProfileDouble(const char* lpAppName,const char* lpKeyName,double dVal,const char* lpFileName)
{

	dictionary* ini;
	char str[64];
	char lpVal[128];
	ini = iniparser_load(lpFileName);
	if(ini==NULL)
	{
		printf("open %s failed\n",lpFileName);
		return -1;
	}
	sprintf(str,"%s:%s",lpAppName,lpKeyName);
	sprintf(lpVal,"%lf",dVal);
	int ret=iniparser_set(ini,(const char*)str,(const char*)lpVal);
	iniparser_save(ini,lpFileName);
	iniparser_freedict(ini);
	return ret;
}
int WritePrivateProfileString(const char* lpAppName,const char* lpKeyName,const char* lpVal,const char* lpFileName)
{

	dictionary* ini;
	char str[64];
	ini = iniparser_load(lpFileName);
	if(ini==NULL)
	{
		printf("open %s failed\n",lpFileName);
		return -1;
	}
	sprintf(str,"%s:%s",lpAppName,lpKeyName);
	int ret=iniparser_set(ini,(const char*)str,lpVal);
	iniparser_save(ini,lpFileName);
	iniparser_freedict(ini);
	return ret;
}

int iniparser_save(dictionary * d, const char *lpFileName)
{
	int ret = 0;
	FILE *fp = NULL;

	if (lpFileName == NULL || d == NULL) {
		ret = -1;
		printf("saveConfig error:%d from (filepath == NULL || head == NULL)\n",ret);
		return ret;
	}

	fp = fopen(lpFileName,"w");
	if (fp == NULL) {
		ret = -2;
		printf("saveConfig:open file error:%d from %s\n",ret,lpFileName);
		return ret;
	}

	iniparser_dump_ini(d,fp);

	fclose(fp);

	return 0;
}
#endif

#ifdef __cplusplus
}
#endif
