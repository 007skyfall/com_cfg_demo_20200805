#include   <stdio.h>
#include   <stdlib.h>
#include   <string.h>
#include   <unistd.h>
#include   <fcntl.h>
#include   <errno.h>
#include   <termios.h>
#include   <sys/time.h>

#include   "serial.h"

int open_port(char *Dev){

    int fd = open( Dev, O_RDWR|O_NOCTTY );
    if (-1 == fd){
        perror("Open Serial Port");
        return -1;
    }
	
    else
        return fd;

}


int set_opt(int fd,int nSpeed, int nBits, char nEvent, int nStop){
    struct termios newtio,oldtio;
    if ( tcgetattr( fd,&oldtio) != 0) {
        perror("SetupSerial 1");
        return -1;
    }
	
    bzero( &newtio, sizeof( newtio ) );
    newtio.c_cflag |= CLOCAL | CREAD;
    newtio.c_cflag &= ~CSIZE;

    switch ( nBits ){
    case 7:
        newtio.c_cflag |= CS7;
        break;
    case 8:
        newtio.c_cflag |= CS8;
        break;
    }

    switch ( nEvent ){
    case 'O':
        newtio.c_cflag |= PARENB;
        newtio.c_cflag |= PARODD;
        newtio.c_iflag |= (INPCK | ISTRIP);
        break;
    case 'E':
        newtio.c_iflag |= (INPCK | ISTRIP);
        newtio.c_cflag |= PARENB;
        newtio.c_cflag &= ~PARODD;
        break;
    case 'N':
        newtio.c_cflag &= ~PARENB;
        break;
    }

    switch ( nSpeed ){
    case 2400:
        cfsetispeed(&newtio, B2400);
        cfsetospeed(&newtio, B2400);
        break;
    case 4800:
        cfsetispeed(&newtio, B4800);
        cfsetospeed(&newtio, B4800);
        break;
    case 9600:
        cfsetispeed(&newtio, B9600);
        cfsetospeed(&newtio, B9600);
        break;
	case 38400:
        cfsetispeed(&newtio, B38400);
        cfsetospeed(&newtio, B38400);
        break;
    case 57600:
        cfsetispeed(&newtio, B57600);
        cfsetospeed(&newtio, B57600);
        break;
    case 115200:
        cfsetispeed(&newtio, B115200);
        cfsetospeed(&newtio, B115200);
        break;
	
    default:
        cfsetispeed(&newtio, B9600);
        cfsetospeed(&newtio, B9600);
        break;
    }
	
    if ( nStop == 1 )
        newtio.c_cflag &= ~CSTOPB;
    else if ( nStop == 2 )
        newtio.c_cflag |= CSTOPB;
    newtio.c_cc[VTIME] = 0;
    newtio.c_cc[VMIN] = 0;
    tcflush(fd,TCIFLUSH);
	
    if ((tcsetattr(fd,TCSANOW,&newtio))!=0){
        perror("com set error");
        return -1;
    }
    return 0;
}


int read_port(int fd, char *buf,int len,int maxwaittime_ms_less1S){
	
	int rc = 0;
    struct timeval tv;
    int no = 0;
    int retry = 2;
    int want_len =  len;
    int nUs = maxwaittime_ms_less1S * 1000 ;  //U SECOND
    fd_set readfd;

    while (retry--){
        tv.tv_sec = 0;
        tv.tv_usec = nUs;

        FD_ZERO(&readfd);
        FD_SET(fd,&readfd);
        rc = select(fd+1, &readfd, NULL, NULL, &tv);
        if (rc>0)
        {
            if (want_len>1)
            {
                usleep(30000);		//30ms
            }
            rc = read(fd, &buf[no], want_len);
            if ((rc>0))
            {
                no += rc;
                want_len -= rc;
            }
            //printf("read COM retry=%d. want len=%d,read len=%d\n",retry,len,no);
            if (want_len <= 0)
            {
                break;
            }
        }
        //printf("read COM select timeout\n");
    }
	
    return no;
	
}
